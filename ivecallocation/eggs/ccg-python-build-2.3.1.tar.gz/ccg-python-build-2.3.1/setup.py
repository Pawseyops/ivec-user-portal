# Create by AH, I use this from my virtual python setup
import setuptools
from setuptools import setup
import ccgfab

setup(name='ccg-python-build',
    version=ccgfab.version(),
    packages=setuptools.find_packages(),
    include_package_data=True,
    package_data={'ccgfab': ['bootstrap.sh']}
)
