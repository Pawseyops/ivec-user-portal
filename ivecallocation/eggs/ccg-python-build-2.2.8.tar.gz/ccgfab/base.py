from fabric.api import env, local, cd, lcd, run, put, settings
from fabric.contrib.console import confirm, prompt
from fabric.context_managers import hide
import os
import vc

__all__ = [
    '_purge',
    '_virtual_python',
    '_chmod',
    '_apacheconfig',
    '_ccg_purge_user',
    '_ccg_purge_snapshot',
    '_ccg_deploy_user',
    '_ccg_deploy_snapshot',
    '_ccg_deploy_release',
    '_code_install',
    'restart',
    'ps',
    'test']

env.repo_path = '' # supply path in repo if app_name not at top level
env.app_root = 'YOU NEED TO SET THIS'
env.app_name = 'YOU NEED TO SET THIS'
env.svn_trunk_url = 'YOU NEED TO SET THIS'
env.svn_tags_url = 'YOU NEED TO SET THIS'

env.writeable_dirs = ['scratch', 'logs']
env.alias_dirs = ['static']

env.auto_confirm_purge = False #purge without asking

env.content_excludes = ["virt_*", "fabfile.py", "ccgfab", ".git", ".gitignore","*.sql", "settings-*", "*.pyc", ".DS_Store", "*.conf", "*dblite", ".svn", ".hg", "tmp", "scratch", "virtualpython", "build-tmp", "*.log"]
env.content_includes = ['*.py', '*.html', '*.mako', '*.txt', '*.png', '*.js', '*.css', '*.jpg', '*.gif', '*.pdf', '*.xml', '*.wsgi', '*.ttf', '*.swf', '*.flv', 'ext-?.?.?' ]

env.rsync_excludes = " ". join(['--exclude "%s"' % X for X in env.content_excludes])
env.rsync_includes = " ". join(['--include "%s"' % X for X in env.content_includes])

if not len(env.hosts):
    env.hosts = ['localhost']

env.ccg_python = '/usr/local/python/cleanpython/bin/python'
env.ccg_virtualenv = '/usr/local/python/cleanpython/bin/virtualenv'
env.ccg_virtualenv_options = '--no-site-packages'
env.ccg_apacheconf = '/usr/local/python/conf/ccg-wsgi'
env.ccg_requirements = 'requirements.txt'

env.ccg_pip_options = '--download-cache=/tmp --use-mirrors'

def _target_localhost():
    if env.hosts[0] == 'localhost' or env.hosts[0] == '127.0.0.1':
        return True
    else:
        return False

def _file_exists(filename):
    command = "[ -f '%s' ]"%(filename)
    with settings(hide('warnings'), warn_only = True):
	if _target_localhost():
	    result = local(command)
	else:
	    result = run(command)
    return True if result.return_code==0 else False

def _run(command, shell=True, pty=True, combine_stderr=None):
    with settings(warn_only=True):
	if _target_localhost():
	    return local(command)
	else:
	    return run(command, shell, pty, combine_stderr)

def _put(local_path=None, remote_path=None, use_sudo=False,
            mirror_local_mode=False, mode=None):
    if _target_localhost():
        sudo = ''
        if use_sudo:
            sudo = 'sudo '
        return local("%scp -a %s %s"%(sudo, local_path, remote_path))
    else:
        return put(local_path, remote_path, use_sudo, mirror_local_mode, mode)

def _get_vc():
    """
    Load the appropriate version control functions
    """
    return vc.create_vc(env)

    
def _purge(target=''):
    """
    Purge a target
    """
    if env.auto_confirm_purge or confirm('Are you sure you want to purge ' + target + ' ?', default=False):
        print _run('sudo rm -rf ' + target)


def _virtual_python(target=None):
    """
    Run the virutal python setup for a given target
    """
    vpython_target = target + '/virtualpython'

    command = "%s %s %s %s" % (env.ccg_python, env.ccg_virtualenv, env.ccg_virtualenv_options, vpython_target)
    print "Building virtualenv with: %s" % command
    print _run(command)
    
    # if we have a requirements.txt then install requirements.txt
    local_filename = os.path.join(target, env.ccg_requirements)
    pre_local_filename = os.path.join(target, "pre-" + env.ccg_requirements)
    post_local_filename = os.path.join(target, "post-" + env.ccg_requirements)
    print "Checking for %s" % pre_local_filename
    if _file_exists(local_filename) :
        if _file_exists(pre_local_filename) :
            print _run('cd ' + target + ' && ' + vpython_target + '/bin/pip install ' + env.ccg_pip_options + ' -r ' + pre_local_filename)
        else:
            print "%s not found" % pre_local_filename

        print _run('cd ' + target + ' && ' + vpython_target + '/bin/pip install ' + env.ccg_pip_options + ' -r ' + local_filename)

        if _file_exists(post_local_filename) :
            print _run('cd ' + target + ' && ' + vpython_target + '/bin/pip install ' + env.ccg_pip_options + ' -r ' + post_local_filename)
        else:
            print "%s not found" % post_local_filename
    else:
        print "%s not found" % local_filename


def _chmod(target):
    with cd(target):
        for directory in env.writeable_dirs:
            directory = os.path.join(target, directory)
            print _run("mkdir -p %s" % directory)
            print _run('chmod 777 %s' % directory)
            print _run('chmod -R ag+w %s' % directory)


def _apacheconfig(target='', buildname='', install_name=''):
    print 'Doing Apacheconfig:'
    print 'target = ', target
    print 'buildname = ', buildname
    print 'install_name = ', install_name
    
    apacheconfig = env.ccg_apacheconf + '/' + install_name + '-' + buildname + '.conf'
    #Delete the old apache config
    print _run('echo WSGIScriptAlias /' + install_name + '/' + buildname + ' ' + target + '/' + env.app_name + '.wsgi > ' + apacheconfig)
    for dir in env.alias_dirs:
        print _run('echo Alias /' + install_name + '/' + buildname + '/' + dir + ' ' + target + '/' + dir + ' >> ' + apacheconfig)

def _purge_apacheconfig(buildname='', install_name=''):
    apacheconfig = env.ccg_apacheconf + '/' + install_name + '-' + buildname + '.conf'
    print _run('sudo rm -f ' + apacheconfig)    


def _ccg_purge_user():
    """
    Purge a user deployment
    """
    for install_name in env.app_install_names:
        target = os.path.join(env.app_root, install_name, env.user)
        _purge(target)


def _ccg_purge_snapshot():
    """
    Purge a snapshot deployment
    """
    for install_name in env.app_install_names:
        target = os.path.join(env.app_root, install_name, 'snapshot')
        _purge(target)


def _ccg_deploy_user(apacheDeployment=True, migration=True):
    """
    User deploy
    """

    src = './'
    _code_install(deploy_type=env.user, src=src, devrelease=True, apacheDeployment=apacheDeployment, migration=migration)

    return env.user


def _ccg_deploy_snapshot(apacheDeployment=True, migration=True):
    """
    Snapshot deploy
    """
    _ccg_purge_snapshot()
    vc = _get_vc()
    release = vc.checkout_trunk()
    #purge the apache config
    for install_name in env.app_install_names:
        _purge_apacheconfig(release, install_name)
    src = os.path.join('fab-tmp/', env.repo_path, env.app_name) + '/'
    _code_install(deploy_type=release, src=src, devrelease=True, apacheDeployment=apacheDeployment, migration=migration)
    print _run('rm -rf fab-tmp')

    return 'snapshot'


def _ccg_deploy_release(devrelease=False, tag=None, apacheDeployment=True, migration=True):
    """
    Release deploy
    """
    vc = _get_vc()
    tag = vc.checkout_tag(tag=tag)
    print "Releasing tag: %s" % tag
    src = os.path.join('fab-tmp/', env.repo_path, env.app_name) + '/'
    _code_install(deploy_type=tag, src=src, devrelease=devrelease, apacheDeployment=apacheDeployment, migration=migration)
    print _run('rm -rf fab-tmp')
    return tag


def _code_install(deploy_type=None, src=None, devrelease=False, apacheDeployment=True, migration=True):
    """
    Code Install
    """
    for install_name in env.app_install_names:
        target_parent = os.path.join(env.app_root, install_name, deploy_type)
        target = os.path.join(target_parent, env.app_name)
        target_python = os.path.join(target, "virtualpython", "bin",  "python")
        print _run('mkdir -p ' + target)
        print local('rm -rf build-tmp')
        print local('mkdir -p build-tmp')
        print local('rsync --delete %s %s -pthrvzC %s %s' % (env.rsync_excludes, env.rsync_includes, src, 'build-tmp'))
        print _put('build-tmp/*', target)
        print local('rm -rf build-tmp')

        _chmod(target)
        _virtual_python(target)

        # invoke manage.py to perform migrations
        # depending on how we are called this may be invoked on a remote machine
        # so we can't rely on the environment being in place
        # env vars we need to set (taken from a top level fabfile):
        # os.environ["DJANGO_SETTINGS_MODULE"]="settings"
        # os.environ["DJANGO_PROJECT_DIR"]=localPaths.getProjectDir()
        # os.environ["PYTHONPATH"] = "/usr/local/etc/ccgapps/:" + localPaths.getProjectDir() + ":" + localPaths.getParentDir()
        # os.environ["PROJECT_DIRECTORY"] = localPaths.getProjectDir()
   
        if migration == True: 
            print _run('export DJANGO_SETTINGS_MODULE="settings" &&' \
                       ' export DJANGO_PROJECT_DIR="%s" &&' \
                       ' export PYTHONPATH="/usr/local/etc/ccgapps/:%s:%s" &&' \
                       ' export PROJECT_DIRECTORY="%s" &&' \
                       ' cd %s &&' \
                       ' %s manage.py syncdb && %s manage.py migrate' % (target, target, target_parent, target, target, target_python, target_python))

        if apacheDeployment:
            _apacheconfig(target, deploy_type, install_name)
            
        # syncdb and migrate have probably created some logfiles with
        # permissions apache can't write to, so run chmod again
        _chmod(target)


def restart():
    """
    Restart Apache
    """
    print _run("sudo /usr/local/python/bin/apachectl restart")


def ps():
    """
    List Apache processes
    """
    print _run('ps -Af | grep apache')
    
def test():
    _run('touch /tmp/fabric.test')
