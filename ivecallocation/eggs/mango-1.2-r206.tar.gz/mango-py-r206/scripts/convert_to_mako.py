#!/usr/bin/env python
"""
Convert one or more Django templates into mako equivalents.

Aim is to eventually give 100% conversion ability 

We are at 0% ATM
"""

import sys

from pyparsing import *

verbose = True

#
# grammar
#

double_quote = Literal('"')
single_quote = Literal("'")

quoted_word_wsingle = Word(alphas+alphanums+":_./ "+"'")
quoted_word_wdouble = Word(alphas+alphanums+":_./ "+'"')


django_double_quote_keyword = Group(double_quote + quoted_word_wsingle + double_quote)
django_single_quote_keyword = Group(single_quote + quoted_word_wdouble + single_quote)

# a django keyword inside the {% %} brackets
django_keyword = Word(alphas+alphanums+'_-.') | django_double_quote_keyword | django_single_quote_keyword

# a django statement
django_statement_core = OneOrMore(django_keyword)
django_statement_compound = django_statement_core + Optional( "|" + django_statement_core )

django_statement = Group("{%" + django_statement_core + "%}")

django_expression = Group("{{" + django_statement_compound + "}}")

django_file = django_statement | django_expression



def main():
    for file in sys.argv[1:]:
        process_file(file)

def process_file(filename):
    """Turn the following django template into a mako template"""
    if verbose:
        print "Converting",filename,"..."
        
        
    file = open(filename).read()
    mako_file = open(filename,"w")
    
    results = django_file.scanString(file)
    last_offset=0               # to keep track of uprocessed regions
    for commands, start, end in results:
        # the html inbetween
        #print "HTML",file[last_offset:start]
        mako_file.write(file[last_offset:start])
        
        # the django token
        for command in commands:
            translate(command, mako_file)
        
        last_offset=end
    
    mako_file.write(file[last_offset:])

def translate(command, fh):
    try:
        fh.write(
            translate_block(command[1:-1]) if command[0]=="{%" else (
                translate_expression(command[1:-1]) if command[0]=='{{' else None
            )
        )
        
    except KeyError, ke:
        fh.write(" ".join([str(a) for a in command]))
        

def convertname(name):
    """given n1.n2.n3 returns n1['n2']['n3']"""
    parts = name.split(".")
    return parts[0]+("".join(["['"+p+"']" for p in parts[1:]]))

def process_blocktrans(items):
    assert len(items)==4, "presently only single assignments supported"
    return '<%def name="blocktrans()"><% '+items[3]+" = "+items[1]+" %>"

def process_url(items):
    if "as" in items:
        start,end = items[:items.index('as')], items[items.index('as'):]
        return "<%% %s = url(%s) %%>"%(end[1],(" ".join(start)).replace("-","_"))
    else:
        return "${ url(%s) }"%((" ".join(items)).replace("-","_"))

def process_load(items):
    if 'admin' in items[0]:
        return '<%%namespace name="admin" module="django.contrib.admin.templatetags.%s" />'%items[0]
    elif items[0] in ('i18n','log'):
        return ''
    else:
        return '<%%namespace name="local" module="%s" />'%items[0]

def dequote(parts):
    if len(parts)==3:
        assert parts[0]=='"' or parts[0]=="'"
        return parts[0]+parts[1]+parts[2]
    else:
        return '"'+parts[0]+'"'

block_commands = {
    'extends': lambda a: '<%%inherit file=%s/>'%dequote(a[0]),
    #'load': lambda a: '<%%include file="%s"/>'%a[0],
    'load': process_load,
    'block': lambda a: '${self.block_%s()}<%%def name="block_%s()">'%(a[0].replace("-","_"),a[0].replace("-","_")),
    'endblock': lambda a: '</%def>',
    'admin_media_prefix': lambda a: '${admin.admin_media_prefix()}',
    'if': lambda a: '\n% if ' + (' '.join([convertname(x) for x in a]))+":\n",
    'for': lambda a: '\n% for ' +  (' '.join([convertname(x) for x in a]))+":\n",
    'blocktrans': process_blocktrans,
    'endblocktrans': lambda a: '</%def>${blocktrans()}',
    'else': lambda a: '\n% else:\n',
    'endif': lambda a: '\n% endif\n',
    'trans': lambda a: '${trans(%s)}'%dequote(a[0]),
    'endfor': lambda a: '\n% endfor\n',
    'url': process_url,
    }

def translate_block(command):
    return block_commands[command[0]](command[1:])
    
def translate_expression(command):
    return "${%s}"%convertname(command[0])

if __name__=="__main__":
    main()