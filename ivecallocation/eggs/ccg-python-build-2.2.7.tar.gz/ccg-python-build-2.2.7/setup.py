# Create by AH, I use this from my virtual python setup
import setuptools
from setuptools import setup

setup(name='ccg-python-build',
    version='2.2.7',
    packages=setuptools.find_packages(),
)
