# Create by AH, I use this from my virtual python setup
import setuptools
from setuptools import setup

setup(name='makoloader',
    version='0.1',
    packages=setuptools.find_packages(),
    namespace_packages = ['django', 'django.template', 'django.template.loaders']
)
