IMPORTANT:

- the file /home/fjanon/ivecallocation/trunk/ivecallocation/django/contrib/admin/filterpces.py
has a fix/hack to filter an admin view with a boolean field of a foreign key.
This hack is NOT checked in the mango project. It is a patch done for ivecallocation until a proper fix is found.
The fix could already be in Django 1.3 or maybe a custom filter in 1.3 would help solving the issue

The mango compressed file has been renamed r206-patched

