"""
Tests for Django's various Request objects.
"""
