from django.contrib.admin.models import LogEntry

def get_admin_log(context, user=None, limit=10):
    if user==None:
        return LogEntry.objects.all().select_related()[:self.limit] 
    return LogEntry.objects.filter(user=user).select_related()[:limit] 
