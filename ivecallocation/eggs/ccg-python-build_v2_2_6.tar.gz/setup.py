# Create by AH, I use this from my virtual python setup
import setuptools
from setuptools import setup

setup(name='ccgfab',
    version='2.2.6',
    packages=setuptools.find_packages(),
)
