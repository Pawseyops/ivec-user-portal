"""
Tests for django.utils.
"""

from dateformat import *
from feedgenerator import *
from module_loading import *
from termcolors import *
from html import *
from http import *
from checksums import *
from text import *
from simplelazyobject import *
from decorators import *
from functional import *
from timesince import *
from datastructures import *
from tzinfo import *
from datetime_safe import *
